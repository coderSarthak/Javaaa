public class Str
{
  public static void main(String[] args)
  {
   String str="Hello";
   for(int i=0;i<str.length()-1;i++)
   {
     for(int j=1;j<str.length()-1;j++)
     {
       if(str.charAt(i) == str.charAt(j))
       {
         System.out.println(str.indexOf(str.charAt(i)));
       }
     }
   }
  }
}