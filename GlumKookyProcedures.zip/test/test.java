public class test{
  public static void main(String[] args)
  {
    System.out.println("class loader for this class");
    System.out.println(test.class.getClassLoader());
  }
}