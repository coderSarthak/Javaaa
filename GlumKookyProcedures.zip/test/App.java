import java.applet.Applet;
import java.awt.Graphics;
public class App extends Applet
{
  public void paint(Graphics g)
  {
    g.drawString("hello",20,40);
  }
  /*
  public static void main(String[] args)*/
}