import java.util.Scanner;
class VowCon
{
  public static void main(String[] args)
  { 
    char a;
    Scanner s=new Scanner(System.in);
    System.out.println("Enter a Character to check if it is a Vowel or Consonant:");
    a=s.next().toLowerCase().charAt(0);
    // nextChar() DOESN'T EXIST
    // charAt().toLowerCase() is illegal syntax 
        // we can't just lowecase the first Character there we have to convert it to lowercase and then select the character index value//
    if(a =='a'||a =='e'||a =='i'||a =='o'||a =='u')
    {
      System.out.println(a+" is  Vowel");
    }
    else
    {
      System.out.println(a+" is Consonant");
 
    }
  }
}