import java.util.Scanner;

class Main {
  public static void main(String[] args)
   {
    Scanner obj = new Scanner(System.in);
    System.out.println("Enter Two numbers:");
    int a = obj.nextInt();
    int b = obj.nextInt();
    System.out.println("1)Addition\n2)Subtraction\n3)Multiplication\n4)Division");
    int c = obj.nextInt();
    switch (c) {
    case 1: System.out.println(a + b);
            break;
    case 2: System.out.println(a - b);
            break;
    case 3: System.out.println(a * b);
            break;
    case 4: System.out.println(a / b);
            break;
    }
    obj.close();
  }
}

