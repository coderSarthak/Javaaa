class Xcep
{
  public static void main(String[] args)
  {
    
    try{
       int[]ar={1,2,3,4,5};
       {
         System.out.println("yes");
       }
       //System.out.println(ar[5]);
    }
    catch(ArrayIndexOutOfBoundsException e)
    {
      System.out.println(e+" <--this is the error");
    }
  }
}