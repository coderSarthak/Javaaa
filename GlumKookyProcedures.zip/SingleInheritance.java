class Subclass1
{
  Subclass1()
  {  System.out.println("Constructor of Subclass1 is here");   }
  public void method()
  {
    System.out.println("Method of Subclass1 is here"); 
  }
}
class Subclass2 extends Subclass1
{
  Subclass2()
  {  System.out.println("Constructor of 'Subclass2' is here");   }
  public void method()
  {
    System.out.println("Method of Subclass2 is here"); 
  }
}

class MultilevelInheritance{
  public static void main(String [] args)
  {
    B obj=new B();
    obj.method();

  }
}