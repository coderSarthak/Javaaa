import java.util.Scanner;

class Input {
  public static void main(String[] args)
  {
      int ip;        
      Scanner obj=new Scanner(System.in);
      System.out.println("What do you Want to print using Scanner?");
      System.out.println("1)Integer Value\n2)Float Value\n3)String");
      ip=obj.nextInt();
      switch(ip)
       {
        case 1:
                System.out.println("You entered an Integer value i.e "+ip); 
                break;
        case 2:
                float b;
                b=obj.nextFloat();
                System.out.println("Given value is "+b);
                break;
        case 3:
                  String c;
                  System.out.println("Enter a String:");
                  c=obj.next();
                  //System.out.println("This is the Entered String \n" +c);
                  System.out.println(c);
                
                  break;         
       }
   }
}