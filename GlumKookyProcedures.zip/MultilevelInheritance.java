class Subclass1
{
  Subclass1()
  {  System.out.println("Constructor of 'Subclass1' is here");   }
  public void method()
  {
    System.out.println("Method of Subclass1 is here"); 
  }
}
class Subclass2 extends Subclass1
{
  Subclass2()
  {  
    super();
    System.out.println("Constructor of 'Subclass2' is here");   
  }
  public void method()
  {
    System.out.println("Method of Subclass2 is here"); 
  }
}
class Subclass3 extends Subclass2
{
  Subclass3()
  {  
    super();
    System.out.println("Constructor of 'Subclass3' is here");   
  }
  public void method()
  {
    System.out.println("Method of Subclass3 is here"); 
  }
}

class MultilevelInheritance{
  public static void main(String [] args)
  {
    Subclass3 obj=new Subclass3();
    obj.method();

  }
}