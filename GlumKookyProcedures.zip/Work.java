package repl.replit;
import repl.Arr;
class Work
{ 
  public static void main(String[] args)
  {
    String A="GoodMorning";
    String B="Morning"; 
    System.out.println("A= "+A+", B= "+B);
    System.out.println(A.substring(1,6));
    
  }
}
