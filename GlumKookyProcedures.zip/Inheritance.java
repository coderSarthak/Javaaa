class A 
{
  A()
  {  System.out.println("Constructor of Class 'A' is here");   }
  public void method()
  {
    System.out.println("Method of Class 'A' is here"); 
  }
}
class B 
{
  B()
  {  System.out.println("Constructor of Class 'B' is here");   }
  public void method()
  {
    System.out.println("Method of Class 'B' is here"); 
  }
}

class SingleInheritance{
  public static void main(String [] args)
  {

  }
}