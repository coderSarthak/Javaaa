public class R
{
  public static void main(String[] args)
  {
    try
    {
      int a=Integer.parseInt("A");
    }
    catch(NumberFormatException e)
          {
      System.out.println(e);
    }
  }
}