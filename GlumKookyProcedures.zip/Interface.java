interface A 
{

 default void  Method()
 {
  System.out.println("This is a method of A");
 }

}
interface B extends A
{
 default void  Method1()
 {
  System.out.println("This is a method of B");
 }

}

interface C extends A
{
 default void Method2()
 {
   System.out.println("This is a method of C");
 }
  
}

class D implements C,B
{
 void Method3()
 {
   System.out.println("This is a method of D");
 }
}
public class Interface  
{
 
  public static void main(String[] args)
  {
   D obj=new D();
   obj.Method3();
  }
}


