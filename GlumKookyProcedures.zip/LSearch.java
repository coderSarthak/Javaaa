import java.util.Scanner;
class LSearch
{
  public static void main(String[] args)
  {
    Scanner obj=new Scanner(System.in);
    int arr[]={5,6,1,8,9,2,0,10};
    int len=arr.length;
    System.out.println("Enter the element");
    int min=obj.nextInt();
    for(int i=0;i<len;i++)
    {
      if(arr[i]==min)
      {
         System.out.println("Element is present at index:"+i);
      }
    }
  }
}