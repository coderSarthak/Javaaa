It is very Rare that the code runs successfully at its first go...😂😁😁
It is common to make mistakes while writing and compiling the code

there are two Kinds of errors....

1) Compile time
  
   All errors are detected and displayed by thr java compiler
   here no .CLASS file is created if any error occured during compilation

2) Run-time errors 
   sometimes there are few cases 
   where  the errors doesn't get detected 
   by JAVA compiler  

   here Since no errors were detected so means .CLASS file
   will be get created

   such programs may produce wrong results 

   for the most common type of runtime-errors go to

   Xcep.java

   Here we have 2 Types
   1️⃣
      In-Built Exceptions transition
   2️⃣
     We can create Our own Exceptions

      User-defined Exceptions

      I have Created a New Txt file named
       💨💨 USER-DEFINED.txt 👈

Note: When catching multiple exceptions, 
the Java compiler requires us to place the
more specific ones before the more general ones,
otherwise they would be unreachable
and would result in a compiler error.