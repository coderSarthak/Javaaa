import java.lang.*;
class UserCreatedException extends Exception
{
  UserCreatedException(String ex)
  {
    super(ex);
  }
}

class UserDefined {
  public static void main(String[] args)
  {
    
    int x=5,y=1000;
    try
    {
      float z=(float)x /(float)y;
      if(z <0.01)
      {
        throw new UserCreatedException(" Got you there! bud");
           // throw is used to create a new exception and throw it.
      }
    }
    catch(UserCreatedException e)
    {
      System.out.println("Suspicious 👩");
      System.out.println(e.getMessage());
    }
    finally{
      System.out.println("i was always there");
    }
    
  }
}