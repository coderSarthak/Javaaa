public class R
{
  public static void main(String[] args)
  {
    /*try
    {
      int a=10,b=0;                             //ArithmeticException e
      int c=a/b;
    }
    catch(ArithmeticException e)
          {
      System.out.println(e);
    }
      */                                    
    /*try
    {
      int [] ar={1,2,3,4,5};                             //ArrayIndexOutOfBoundsException e
      System.out.println(ar[6]);
    }
    catch(ArrayIndexOutOfBoundsException e)
          {
      System.out.println(e);
    }*/

    /*try{
      String ar="1:2:3";
      System.out.println(ar.charAt(5));
                                              //StringIndexOutOfBoundsException e
    }
    catch(StringIndexOutOfBoundsException e)
    {
      System.out.println(e);
    }
    */

   /* try{
       String a = null;
       System.out.println(a.charAt(0));                                //NUllPointException 
    }
    catch(NullPointerException e)
    {
      System.out.println("NullPointerException -->");
      e.printStackTrace();
    }
       */

    /*try
    {
      //I havent try this coz i was not able/ready to deal with files and formats A.T.M                                       //FileNotFoundException e
    }
    catch
    {

    }
   */
    /*try
    {
      //I havent try this coz i was not able/ready to deal with Applets  A.T.M                                       
    }
    catch
    {

    }
   */
    /*try
    {
      //I havent try this coz i was not able/ready to deal with  A.T.M                                       
    }
    catch
    {

    }
   */

  /*public static void main(String[] args)
  {
    try
    {                                             
      int a=Integer.parseInt("A");            // NumberFormatException e
    }
    catch(NumberFormatException e)
          {
      System.out.println(e);
    }*/
  }
}