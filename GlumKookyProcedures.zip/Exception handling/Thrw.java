class Thrw {

  //This is a program to show how to use Throw 
     // i was thinking if JAVA can
      // throw the error/exception ,WHY can we 
        //use Throw to get a sting whenever
         // an there is an error occurs
  public static void main(String[] args){
  try
  {
    int a=0,b=20;
    System.out.println(b/a);
    /*if((b/a)==2)
    {
      System.out.println("Yes!");
    }
    else
    { throw new ArithmeticException(" written Error"); }*/
  } 
  catch(NullPointerException t)
  {
    System.out.println("Errrrrrorrrs"+t);
  }
  catch(NumberFormatException g)
  {
    System.out.println(g);
  }
  catch(ArithmeticException e)
    {
     System.out.println("Caught you! "+e);
    }
  }
}