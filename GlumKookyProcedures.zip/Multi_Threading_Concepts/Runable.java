

class Runable implements Runnable
{

  public void run()
  {
    System.out.println("Thread start running");
  }
  public static void main(String[] args)
  {
    Runable obj=new Runable();
    new Thread().start();
    new Thread(obj).start();
    new Thread(obj).start();
    new Thread(obj).start();

  }
}