class Rough extends Thread
{
  Rough()
  {
    super("My extending thread");

    System.out.println("My thread created "+this);
    start();
  }
  public void run()
  {
    try
    {
      for(int i=0;i<10;i++)
      {
        System.out.println("Thread count: "+i);
        Thread.sleep(100);
      }
    }
      catch(InterruptedException e)
      {
        System.out.println(e);
      }
      System.out.println("Thread process is over");
    }
  public static void main(String[] args)
  {
    Rough obj=new Rough();
    try
    {
      while(obj.isAlive())
      {
       System.out.println("Thread continues till end");
       Thread.sleep(1400);
      }

    }
    catch(InterruptedException e)
      {
        System.out.println(e);
        
      }
    //obj.start();
  }
}