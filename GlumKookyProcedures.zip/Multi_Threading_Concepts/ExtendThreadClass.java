class ExtendThreadClass extends Thread
{
  public void run()
  {
    System.out.println("Thread Started Running" ); 
     // This will give the currentThread id  of the thread        
           //  ---> /* +Thread.currentThread().getId());*/
  }
  public static void main(String[] args)
  {
    /*ExtendThreadClass obj=new ExtendThreadClass();
    obj.start();*/
    Thread obj=new Thread("extended");
    obj.start();
    System.out.println(obj.getId());
    /* When a thread is in running state, and you try to 
     start it again, or any method try 
      to invoke that thread again using start()
       method, exception is thrown.*/

    /*new ExtendThreadClass().start();
    new ExtendThreadClass().start();
    new ExtendThreadClass().start();  // Every time we have created 
                             //a new object here & Started the process
    new ExtendThreadClass().start();
    new ExtendThreadClass().start();
    new ExtendThreadClass().start();*/
  }

}