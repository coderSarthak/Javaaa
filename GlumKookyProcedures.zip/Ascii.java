import java.util.Scanner;
class Ascii
{
  public static void main(String[] args)
  {
    Scanner a = new Scanner(System.in);
    System.out.println("Enter a Character to know its Ascii value");
    char c = a.next().charAt(0);
    System.out.println((int)c);
    /*for(char i='A';i<='z';i++)
    {
      System.out.println(((int)i)+"\n");
    }*/
 
 

  }

}