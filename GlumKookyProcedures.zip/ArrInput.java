import java.util.Scanner;
class ArrInput
{
  public static void main(String []args)
  {
    int input,l;
    Scanner obj=new Scanner(System.in);
    System.out.println("Enter the number of elements you want to insert");
    l=obj.nextInt();
    int []arr=new int[l];
    for(int i=0;i<l;i++)
    {
      arr[i]=obj.nextInt();
    }
    System.out.println("The Elements you've entered are");
    for(int j=0;j<l;j++)
    {  System.out.print(arr[j]+" ");  }
  }
}