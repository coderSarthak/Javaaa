import java.util.Scanner;
class Swap
{
  public static void main(String[] args)
  {
     Scanner obj=new Scanner(System.in);
     int a,b;
     System.out.println("Enter the Two numbers");
     a=obj.nextInt();
     b=obj.nextInt();
     System.out.println("Entered two numbers a & b are "+ a +","+ b);
     a=a+b;
     b=a-b;
     a=a-b;
     System.out.println("After Swapping two numbers a & b are "+ a +","+ b);     

  }
}