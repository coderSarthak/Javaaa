import java.util.Scanner;
class BSearch
{
  public static void main(String[] args)
  {
    int ar[]= {66,9,7,1,5,10};
  int start=0;
  int end=ar.length;
  int item=9;
  int loc=0;
  int mid=(start+end)/2;
  while(start<=end)
  {
	  if(item==ar[mid])
		 loc=ar[mid];
	  else if(item<=ar[mid])
		  end=mid-1;
	  else
		  start=mid+1;  
  mid=(start+end)/2;
 }
  if(loc!=0)
  {
	  System.out.println("item found at"+ar[loc]);
  }
  }
}