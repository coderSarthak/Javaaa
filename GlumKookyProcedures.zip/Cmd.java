class Cmd{
  // Program to print elements using command line arguments//
  public static void main(String[] args)
  {
    //to print cmd line args 
    /*for(int i=0;i<args.length;i++) 
    {    System.out.println(args[i]);   }*/

   /* for(int i=0;i<args.length;i++)
    { System.out.print(args[i]+" "); }*/
 
    int sum=0;
    for(int i=0;i<args.length;i++)
    {
      sum += Integer.parseInt(args[i]);
          //+= (args[i]) ;
      //System.out.println(sum);
    }
    System.out.println(sum);
    
  }
}
