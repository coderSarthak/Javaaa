import javax.swing.JFrame;
import javax.swing.JLabel;

class New
{
  public static void main(String[] args)
  {
      JFrame window=new JFrame();
      window.setTitle("My Window");
      window.setSize(200,400);
      window.setVisible(true);
      JLabel obj=new JLabel();
      obj.setText("MY label");
      window.add(obj);
  }

}