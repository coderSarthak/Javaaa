import repl.Arr;
class Hell
{
   // This is a code in 
     //which we have used the package by importing
    // it using "import packagename.ClassName"
  public static void main(String[] args)
  {
    Arr obj=new Arr();
    obj.Pri();
  }
}