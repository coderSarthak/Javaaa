import java.util.Scanner;
class Ly
 { 
   public static void main(String[] args)
   { 
     Scanner obj=new Scanner(System.in);
     System.out.println("Enter Year to check Whether it is a leap year or not");
     int a =obj.nextInt();
     if((a%4 ==0)&&(a%100 !=0) ||(a%400) ==0)
       {
        System.out.println("Leap year Alert!!");                
       }
     else
       {
        System.out.println("Not a leap year");             
       }         
      obj.close();
              
    }
} 