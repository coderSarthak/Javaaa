class abc extends Thread
{
  public void run()
  {
    System.out.println("Thread running");
  }
  public static void main(String[] args)
  {
     abc obj=new abc();
     obj.start();
     System.out.println("Thread priority Max= "+obj.MAX_PRIORITY);
     System.out.println("Thread priority Min= "+obj.MIN_PRIORITY);
     System.out.println("Thread priority default= "+obj.NORM_PRIORITY);
  }
}