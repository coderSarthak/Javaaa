import java.util.Scanner;

class Area {
  public static void main(String[] args) {
    int a, b;
    double PI = 3.14;
    Scanner obj = new Scanner(System.in);
    System.out.println("1)Area of Circle\n2)Area of Triangle\n3)Area of Rectangle\n4)Area of Square");
    a = obj.nextInt();
    switch (a) {
    case 1:
            System.out.println("Enter radius value:");
            a = obj.nextInt();
            System.out.println(PI * (a * a));
            break;
    case 2:
            System.out.println("Enter Height value:");
            a = obj.nextInt();
            System.out.println("Enter Base value:");
            b = obj.nextInt();
            System.out.println((a * b) / 2);
            break;
    case 3:
            System.out.println("Enter Length value:");
            a = obj.nextInt();
            System.out.println("Enter Width value:");
            b = obj.nextInt();
            System.out.println(a * b);
            break;
    case 4:
            System.out.println("Enter the value:");
            a = obj.nextInt();
            System.out.println(a * a);
            break;
    }
    obj.close();
  }
}