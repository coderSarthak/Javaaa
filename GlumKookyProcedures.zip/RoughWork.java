class RoughWork
{
  public static void main(String[] args)
  {
    //String a = "10";
    int a=10;
    int b=9;
    int c=Integer.compare(b, (a));
   // boolean d=(c==0);   
    System.out.print(c);
  }
}