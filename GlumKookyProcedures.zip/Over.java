class Parent 
{
  private void m1()
  {
    System.out.println("Parent m1 here");
  }
  protected void m2()
  {
    System.out.println("Parent m2 here");
  }
}

class Child extends Parent 
{
  private void m1()
  {
    System.out.println("Child m1 here");
  }
  @Override
  public void m2()
  {
    System.out.println("Child m2 here");
  }
}

class Over{
  public static void main(String[] args)
  {
     Parent obj=new Parent();
     obj.m2();
     Parent obj2=new Child();
     obj2.m2();
  }
}